﻿using System;

namespace RoleplayersToolbox.Tools {
    [Serializable]
    internal partial class ToolConfig {
    }
}
