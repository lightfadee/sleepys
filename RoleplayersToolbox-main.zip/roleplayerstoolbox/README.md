# The Roleplayer's Toolbox

## Install

- Add `https://plugins.annaclemens.io/unofficial` to your custom repositories.
- Install via `/xlplugins`.
